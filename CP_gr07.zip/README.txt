The page should be initialized by the login-signup.html page

Authors:

Pablo Montero Poyatos,
Mario García Hidalgo,
Marta Guirao Alcaraz,
Miguel Eduardo Porras Valenzuela
